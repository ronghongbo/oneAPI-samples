set -x
source setenv.sh devcloud opencl fpga
aoc -v -profile -fpc -fp-relaxed -high-effort -board=pac_a10 large-sgemm-clearOpencl.cl

