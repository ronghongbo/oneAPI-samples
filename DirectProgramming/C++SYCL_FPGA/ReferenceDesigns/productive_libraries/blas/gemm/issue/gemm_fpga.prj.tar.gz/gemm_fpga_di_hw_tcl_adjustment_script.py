di_hw_tcl_file = 'gemm_fpga_di_hw.tcl' # Generated in System Integrator

original_di_hw_tcl = open(di_hw_tcl_file, 'r') # Original
old_di_hw_tcl = open(di_hw_tcl_file + '_original', 'w') # Store old copy
adjustments = open('adjustments_di_hw_tcl.log', 'w') # Store adjustment logs

old_content = [] # Save content for reparssing *_di_hw.tcl
content = [] # Content to replace *_di_hw.tcl

# Check to remove the following lines
to_remove = ['add_interface clock_reset clock end',
             'set_interface_property clock_reset ENABLED true',
             'add_interface_port clock_reset clock clk Input 1',
             'add_interface_port clock_reset resetn reset_n Input 1',
             'add_interface clock_reset2x clock end',
             'set_interface_property clock_reset2x ENABLED true',
             'add_interface_port clock_reset2x clock2x clk Input 1']

is_resetn_sync_added = False
for line in original_di_hw_tcl: # Parse through file details
    old_di_hw_tcl.write(line) # Keep old copy in sync
    old_content.append(line)
    
    if 'set_interface_property resetn synchronousEdges' in line: # Don't add sync
        is_resetn_sync_added = True
old_di_hw_tcl.close()
        
for line in old_content: # Parse through file details
    is_ignore = False # Used as a boolean to not add in lines for removal

    if 'associatedReset' in line: # Remove associatedReset lines
        adjustments.write('Removed: ' + line)
        is_ignore = True
        
    if is_ignore == True:
        continue
    
    for remove_line in to_remove: # Validation to remove unwanted lines from to_remove
        if remove_line in line:
            adjustments.write('Removed: ' + line)
            is_ignore = True
            break
            
    if is_ignore == True:
        continue
    
    # Replacement adjustments
    if 'associatedClock clock_reset' in line:
        adjustments.write('Adjusted associatedClock clock_reset to clock for: ' + line)
        line = line.replace('associatedClock clock_reset', 'associatedClock clock')
    elif 'add_interface resetn conduit end' in line:
        adjustments.write('Adjusted type conduit to type reset for: ' + line)
        line = line.replace('conduit', 'reset')
    elif 'set_interface_property resetn associatedClock clock' in line and is_resetn_sync_added == False:
        adjustments.write('Added synchronousEdges BOTH after: ' + line)
        line += 'set_interface_property resetn synchronousEdges BOTH\n'
    elif 'add_interface_port resetn resetn data' in line:
        adjustments.write('Adjusted qsys description of data to reset_n for: ' + line)
        line = line.replace('data', 'reset_n')
        
    content.append(line) # Add into content to write into file once all parsed

original_di_hw_tcl.close()

# All changes now replaced in the di_hw.tcl file
adjusted_di_hw_tcl = open(di_hw_tcl_file, 'w')
for line in content:
    adjusted_di_hw_tcl.write(line)
adjusted_di_hw_tcl.close()
adjustments.close()

print('Success! Adjusted ' + di_hw_tcl_file + ' file!')
print('The adjustment log is in: adjustments_di_hw_tcl.log')
print('The original file is in: ' + di_hw_tcl_file + '_original')

