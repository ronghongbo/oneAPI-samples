#if __has_include(<sycl/sycl.hpp>)
#include <sycl/sycl.hpp>
#else
#include <CL/sycl.hpp>
#endif
#include <sycl/ext/intel/fpga_extensions.hpp>

#include "halide_runtime_etc.hpp"
#include "pipe_wrapper.hpp"
#include "complex_helper.hpp"
#include "constexpr_math.hpp"
#include "tuple.hpp"
#include "unrolled_loop.hpp"

template <typename... Args>
void log(Args &&...args) {
#ifndef T2SP_NDEBUG
  ((std::cout << "[INFO] ") << ... << args) << "\n";
#endif
}

using namespace sycl;
namespace t2sp::blas::row_major::sdotprod {

typedef union {
bool __attribute__ ((aligned(16))) s[16];
struct {bool s0,  s1,  s2,  s3,  s4,  s5,  s6,  s7,  s8,  s9,  sa,  sb,  sc,  sd,  se,  sf;};
} bool16;
using xLoader_1_channel = pipe_wrapper<class xLoader_1_channel_pipe, float16, 0>;
using yLoader_1_channel = pipe_wrapper<class yLoader_1_channel_pipe, float16, 0>;
using Z_channel = pipe_wrapper<class Z_channel_pipe, float, 0, 64>;
struct Out_channel_array_t { float s; };
using Out_channel = pipe_wrapper<class Out_channel_pipe, Out_channel_array_t, 256>;
sycl::event sdotprod(sycl::queue &q_device, bool ConjugateX, struct halide_buffer_t *X_buffer, int32_t IncX, bool SignBitY, struct halide_buffer_t *Y_buffer, int32_t IncY, bool SqrtRet, struct halide_buffer_t *deserializer_1_buffer) {
  std::vector<sycl::event> oneapi_kernel_events{};
  std::vector<size_t> kernels_used_to_measure_time{};
  auto exception_handler = [](sycl::exception_list exceptions) {
    for (std::exception_ptr const &e : exceptions) {
      try {
        std::rethrow_exception(e);
      } catch (sycl::exception const &e) {
        std::cout << "Caught asynchronous SYCL exception:\n"
                  << e.what() << std::endl;
      }
    }
  };
  log("creating device queues");
  sycl::queue q_host(sycl::cpu_selector_v, exception_handler, sycl::property::queue::enable_profiling());
  log("Host: ", q_host.get_device().get_info<sycl::info::device::name>());
  log("Device: ", q_device.get_device().get_info<sycl::info::device::name>());
  sycl::device dev = q_device.get_device();
  void * const _ucon = nullptr;
  void * X = _halide_buffer_get_host(X_buffer);
  uint32_t X_type = _halide_buffer_get_type(X_buffer);
  int32_t X_dimensions = _halide_buffer_get_dimensions(X_buffer);
  int32_t X_min_0 = _halide_buffer_get_min(X_buffer, 0);
  int32_t X_extent_0 = _halide_buffer_get_extent(X_buffer, 0);
  int32_t X_stride_0 = _halide_buffer_get_stride(X_buffer, 0);
  int32_t X_min_1 = _halide_buffer_get_min(X_buffer, 1);
  int32_t X_extent_1 = _halide_buffer_get_extent(X_buffer, 1);
  int32_t X_stride_1 = _halide_buffer_get_stride(X_buffer, 1);
  void * Y = _halide_buffer_get_host(Y_buffer);
  uint32_t Y_type = _halide_buffer_get_type(Y_buffer);
  int32_t Y_dimensions = _halide_buffer_get_dimensions(Y_buffer);
  int32_t Y_min_0 = _halide_buffer_get_min(Y_buffer, 0);
  int32_t Y_extent_0 = _halide_buffer_get_extent(Y_buffer, 0);
  int32_t Y_stride_0 = _halide_buffer_get_stride(Y_buffer, 0);
  int32_t Y_min_1 = _halide_buffer_get_min(Y_buffer, 1);
  int32_t Y_extent_1 = _halide_buffer_get_extent(Y_buffer, 1);
  int32_t Y_stride_1 = _halide_buffer_get_stride(Y_buffer, 1);
  void * deserializer_1 = _halide_buffer_get_host(deserializer_1_buffer);
  uint32_t deserializer_1_type = _halide_buffer_get_type(deserializer_1_buffer);
  int32_t deserializer_1_dimensions = _halide_buffer_get_dimensions(deserializer_1_buffer);
  int32_t deserializer_1_min_0 = _halide_buffer_get_min(deserializer_1_buffer, 0);
  int32_t deserializer_1_extent_0 = _halide_buffer_get_extent(deserializer_1_buffer, 0);
  int32_t deserializer_1_stride_0 = _halide_buffer_get_stride(deserializer_1_buffer, 0);
  if (_halide_buffer_is_bounds_query(X_buffer)) {
    struct halide_dimension_t s0[2] = {
      {X_min_0, X_extent_0, IncX, 0},
      {X_min_1, X_extent_1, X_extent_0, 0},
    };
  }
  if (_halide_buffer_is_bounds_query(Y_buffer)) {
    struct halide_dimension_t s1[2] = {
      {Y_min_0, Y_extent_0, IncY, 0},
      {Y_min_1, Y_extent_1, Y_extent_0, 0},
    };
  }
  if (_halide_buffer_is_bounds_query(deserializer_1_buffer)) {
    struct halide_dimension_t s2[1] = {
      {0, X_extent_1, 1, 0},
    };
  }
  if (!(_halide_buffer_is_bounds_query(deserializer_1_buffer) || (_halide_buffer_is_bounds_query(X_buffer) || _halide_buffer_is_bounds_query(Y_buffer)))) {
    int64_t X_total_extent_1 = (int64_t)(X_extent_1) * (int64_t)(X_extent_0);
    int64_t Y_total_extent_1 = (int64_t)(Y_extent_1) * (int64_t)(Y_extent_0);
    halide_buffer_t b0;
    struct halide_dimension_t s3[4] = {
      {0, 16, 1, 0},
      {0, 64, 16, 0},
      {0, (X_extent_0 + 1023) / 1024, 1024, 0},
      {0, X_extent_1, (X_extent_0 + 1023) / 1024 * 1024, 0},
    };
    struct halide_dimension_t s4[4] = {
      {0, 16, 1, 0},
      {0, 64, 16, 0},
      {0, (X_extent_0 + 1023) / 1024, 1024, 0},
      {0, X_extent_1, (X_extent_0 + 1023) / 1024 * 1024, 0},
    };
    struct halide_buffer_t * xSerializer_1_mem_channel_buffer = _halide_buffer_init(&b0, s3, (void *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), (uint64_t)(ADD_UINT64_T_SUFFIX(0)), (struct halide_device_interface_t *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), 2, 32, 4, s4, (uint64_t)(ADD_UINT64_T_SUFFIX(0)));
    int32_t halide_device_and_host_malloc_result_2 = 0;
    halide_sycl_device_and_host_malloc(xSerializer_1_mem_channel_buffer, q_device);
;
    {
      float *xSerializer_1_mem_channel = (float *)(_halide_buffer_get_host(xSerializer_1_mem_channel_buffer));
      if (!xSerializer_1_mem_channel)
      {
        log("Condition 'xSerializer_1_mem_channel' failed with error id_msg: None");
        assert(false);
      }
      {
        int32_t addr_temp;
        addr_temp = 0;
        int32_t halide_copy_to_host_result_1 = 0;
        halide_sycl_buffer_copy(X_buffer, 1, q_device);
;
        // kernel_xSerializer_1
        log("kernel kernel_xSerializer_1");
        float *X = (float*)(X_buffer->host);
        xSerializer_1_mem_channel = (float*)(xSerializer_1_mem_channel_buffer->host);
        {
          for (int b = 0; b < X_extent_1; b++) {
            for (int k = 0; k < (X_extent_0 + 1023) / 1024; k++) {
              for (int kk = 0; kk < 64; kk++) {
                for (int kkk = 0; kkk < 16; kkk++) {
                  if ((k * 64 + kk) * 16 < X_extent_0) {
                    auto _D0 = (k * 1024 + (kk * 16 + kkk)) * IncX + X_stride_1 * b - (IncX * X_min_0 + X_min_1 * X_stride_1);
                    xSerializer_1_mem_channel[addr_temp] = ((float *)X)[_D0];
                  }
                  addr_temp = addr_temp + 1;
                }
              }
            }
          }
        }
        _halide_buffer_set_host_dirty(xSerializer_1_mem_channel_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
      }
      halide_sycl_buffer_copy(xSerializer_1_mem_channel_buffer, 0, q_device);

      kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
      // kernel_xLoader_1
      log("kernel kernel_xLoader_1");
      xSerializer_1_mem_channel = (float*)(((device_handle*) xSerializer_1_mem_channel_buffer->device)->mem);
      oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
        h.single_task<class kernel_xLoader_1_class>([=](){
          int addr_temp;
          addr_temp = 0;
          for (int b = 0; b < X_extent_1; b++) {
            for (int k = 0; k < (X_extent_0 + 1023) >> 10; k++) {
              for (int kk = 0; kk < 64; kk++) {
                xLoader_1_channel::write<>(((k * 64 + kk) * 16 < X_extent_0 ? float16{
                  xSerializer_1_mem_channel[addr_temp * 16 + 0],
                  xSerializer_1_mem_channel[addr_temp * 16 + 1],
                  xSerializer_1_mem_channel[addr_temp * 16 + 2],
                  xSerializer_1_mem_channel[addr_temp * 16 + 3],
                  xSerializer_1_mem_channel[addr_temp * 16 + 4],
                  xSerializer_1_mem_channel[addr_temp * 16 + 5],
                  xSerializer_1_mem_channel[addr_temp * 16 + 6],
                  xSerializer_1_mem_channel[addr_temp * 16 + 7],
                  xSerializer_1_mem_channel[addr_temp * 16 + 8],
                  xSerializer_1_mem_channel[addr_temp * 16 + 9],
                  xSerializer_1_mem_channel[addr_temp * 16 + 10],
                  xSerializer_1_mem_channel[addr_temp * 16 + 11],
                  xSerializer_1_mem_channel[addr_temp * 16 + 12],
                  xSerializer_1_mem_channel[addr_temp * 16 + 13],
                  xSerializer_1_mem_channel[addr_temp * 16 + 14],
                  xSerializer_1_mem_channel[addr_temp * 16 + 15]
                } : float16{float_from_bits(0)}));
                addr_temp = addr_temp + 1;
              }
            }
          }
        }); //  h.single_task kernel_xLoader_1_class
      })); // q_device.submit
      halide_buffer_t b1;
      struct halide_dimension_t s5[4] = {
        {0, 16, 1, 0},
        {0, 64, 16, 0},
        {0, (X_extent_0 + 1023) / 1024, 1024, 0},
        {0, X_extent_1, (X_extent_0 + 1023) / 1024 * 1024, 0},
      };
      struct halide_dimension_t s6[4] = {
        {0, 16, 1, 0},
        {0, 64, 16, 0},
        {0, (X_extent_0 + 1023) / 1024, 1024, 0},
        {0, X_extent_1, (X_extent_0 + 1023) / 1024 * 1024, 0},
      };
      struct halide_buffer_t * ySerializer_1_mem_channel_buffer = _halide_buffer_init(&b1, s5, (void *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), (uint64_t)(ADD_UINT64_T_SUFFIX(0)), (struct halide_device_interface_t *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), 2, 32, 4, s6, (uint64_t)(ADD_UINT64_T_SUFFIX(0)));
      int32_t halide_device_and_host_malloc_result_1 = 0;
      halide_sycl_device_and_host_malloc(ySerializer_1_mem_channel_buffer, q_device);
;
      {
        float *ySerializer_1_mem_channel = (float *)(_halide_buffer_get_host(ySerializer_1_mem_channel_buffer));
        if (!ySerializer_1_mem_channel)
        {
          log("Condition 'ySerializer_1_mem_channel' failed with error id_msg: None");
          assert(false);
        }
        {
          int32_t addr_temp;
          addr_temp = 0;
          int32_t halide_copy_to_host_result_2 = 0;
          halide_sycl_buffer_copy(Y_buffer, 1, q_device);
;
          // kernel_ySerializer_1
          log("kernel kernel_ySerializer_1");
          float *Y = (float*)(Y_buffer->host);
          ySerializer_1_mem_channel = (float*)(ySerializer_1_mem_channel_buffer->host);
          {
            for (int b = 0; b < X_extent_1; b++) {
              for (int k = 0; k < (X_extent_0 + 1023) / 1024; k++) {
                for (int kk = 0; kk < 64; kk++) {
                  for (int kkk = 0; kkk < 16; kkk++) {
                    if ((k * 64 + kk) * 16 < X_extent_0) {
                      auto _D1 = (k * 1024 + (kk * 16 + kkk)) * IncY + Y_stride_1 * b - (IncY * Y_min_0 + Y_min_1 * Y_stride_1);
                      ySerializer_1_mem_channel[addr_temp] = ((float *)Y)[_D1];
                    }
                    addr_temp = addr_temp + 1;
                  }
                }
              }
            }
          }
          _halide_buffer_set_host_dirty(ySerializer_1_mem_channel_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
        }
        halide_sycl_buffer_copy(ySerializer_1_mem_channel_buffer, 0, q_device);

        kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
        // kernel_yLoader_1
        log("kernel kernel_yLoader_1");
        ySerializer_1_mem_channel = (float*)(((device_handle*) ySerializer_1_mem_channel_buffer->device)->mem);
        oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
          h.single_task<class kernel_yLoader_1_class>([=](){
            int addr_temp;
            addr_temp = 0;
            for (int b = 0; b < X_extent_1; b++) {
              for (int k = 0; k < (X_extent_0 + 1023) >> 10; k++) {
                for (int kk = 0; kk < 64; kk++) {
                  auto _D2 = addr_temp * 16;
                  auto _D3 = addr_temp * 16;
                  yLoader_1_channel::write<>(((k * 64 + kk) * 16 < X_extent_0 ? halide_conditional_signbit(SignBitY, float16{
                    ySerializer_1_mem_channel[_D3 + 0],
                    ySerializer_1_mem_channel[_D3 + 1],
                    ySerializer_1_mem_channel[_D3 + 2],
                    ySerializer_1_mem_channel[_D3 + 3],
                    ySerializer_1_mem_channel[_D3 + 4],
                    ySerializer_1_mem_channel[_D3 + 5],
                    ySerializer_1_mem_channel[_D3 + 6],
                    ySerializer_1_mem_channel[_D3 + 7],
                    ySerializer_1_mem_channel[_D3 + 8],
                    ySerializer_1_mem_channel[_D3 + 9],
                    ySerializer_1_mem_channel[_D3 + 10],
                    ySerializer_1_mem_channel[_D3 + 11],
                    ySerializer_1_mem_channel[_D3 + 12],
                    ySerializer_1_mem_channel[_D3 + 13],
                    ySerializer_1_mem_channel[_D3 + 14],
                    ySerializer_1_mem_channel[_D3 + 15]
                  }) /* conditional_signbit_f32((bool16){{SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY, SignBitY}}, float16{
                    ySerializer_1_mem_channel[_D2 + 0],
                    ySerializer_1_mem_channel[_D2 + 1],
                    ySerializer_1_mem_channel[_D2 + 2],
                    ySerializer_1_mem_channel[_D2 + 3],
                    ySerializer_1_mem_channel[_D2 + 4],
                    ySerializer_1_mem_channel[_D2 + 5],
                    ySerializer_1_mem_channel[_D2 + 6],
                    ySerializer_1_mem_channel[_D2 + 7],
                    ySerializer_1_mem_channel[_D2 + 8],
                    ySerializer_1_mem_channel[_D2 + 9],
                    ySerializer_1_mem_channel[_D2 + 10],
                    ySerializer_1_mem_channel[_D2 + 11],
                    ySerializer_1_mem_channel[_D2 + 12],
                    ySerializer_1_mem_channel[_D2 + 13],
                    ySerializer_1_mem_channel[_D2 + 14],
                    ySerializer_1_mem_channel[_D2 + 15]
                  }) replaced */ : float16{float_from_bits(0)}));
                  addr_temp = addr_temp + 1;
                }
              }
            }
          }); //  h.single_task kernel_yLoader_1_class
        })); // q_device.submit
        kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
        // kernel_Out
        log("kernel kernel_Out");
        oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
          h.single_task<class kernel_Out_class>([=](){
            Out_channel_array_t Out_channel_array;
            for (int b = 0; b < X_extent_1; b++) {
              int addr_temp;
              addr_temp = 0;
              float uZ_1_shreg[64];
              float Z_temp_shreg[64];
              for (int k = 0; k < (X_extent_0 + 1023) >> 10; k++) {
                for (int kk = 0; kk < 64; kk++) {
                  float uZ_1;
                  uZ_1 = uZ_1_shreg[63];
                  fpga_tools::UnrolledLoop<63>([&](auto l1) {
                    uZ_1_shreg[63 - l1] = uZ_1_shreg[62 - l1];
                  });
                  uZ_1_shreg[0] = uZ_1;
                  float16 uY_shreg;
                  float16 uX_shreg;
                  uX_shreg = xLoader_1_channel::read<>();
                  uY_shreg = yLoader_1_channel::read<>();
                  float uZ_1_shreg_;
                  uZ_1_shreg_ = (k == 0 ? float_from_bits(0) : sycl::ext::intel::fpga_reg(uZ_1_shreg[0]));
                  fpga_tools::UnrolledLoop<16>([&](auto kkk) {
                    uZ_1_shreg_ = uZ_1_shreg_ + uX_shreg[kkk] * uY_shreg[kkk];
                    if ((kkk & 3) == 3) {
                      uZ_1_shreg_ = sycl::ext::intel::fpga_reg(uZ_1_shreg_);
                    }
                  });
                  uZ_1_shreg[0] = uZ_1_shreg_;
                  fpga_tools::UnrolledLoop<16>([&](auto kkk) {
                    if (k == (X_extent_0 - 1) >> 10 && kkk == 15) {
                      Z_temp_shreg[addr_temp] = uZ_1_shreg[0];
                      addr_temp = addr_temp + 1;
                    }
                  });
                }
              }
              addr_temp = 0;
              float uZ_2_shreg[64];
              fpga_tools::UnrolledLoop<64>([&](auto kk) {
                uZ_2_shreg[kk] = Z_temp_shreg[addr_temp] + ((kk == 0 ? float_from_bits(0) : uZ_2_shreg[kk + -1]));
                if (kk == 63) {
                  Out_channel_array.s = (SqrtRet ? std::sqrt(uZ_2_shreg[63]) : uZ_2_shreg[63]) /* conditional_sqrt_f32(SqrtRet, uZ_2_shreg[63]) replaced */;
                }
                addr_temp = addr_temp + 1;
              });
              Out_channel::write<>(Out_channel_array);
            }
          }); //  h.single_task kernel_Out_class
        })); // q_device.submit
        halide_buffer_t b2;
        struct halide_dimension_t s7[1] = {
          {0, X_extent_1, 1, 0},
        };
        struct halide_dimension_t s8[1] = {
          {0, X_extent_1, 1, 0},
        };
        struct halide_buffer_t * unloader_1_mem_channel_buffer = _halide_buffer_init(&b2, s7, (void *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), (uint64_t)(ADD_UINT64_T_SUFFIX(0)), (struct halide_device_interface_t *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), 2, 32, 1, s8, (uint64_t)(ADD_UINT64_T_SUFFIX(0)));
        int32_t halide_device_and_host_malloc_result = 0;
        halide_sycl_device_and_host_malloc(unloader_1_mem_channel_buffer, q_device);
;
        {
          float *unloader_1_mem_channel = (float *)(_halide_buffer_get_host(unloader_1_mem_channel_buffer));
          if (!unloader_1_mem_channel)
          {
            log("Condition 'unloader_1_mem_channel' failed with error id_msg: None");
            assert(false);
          }
          halide_sycl_device_malloc(unloader_1_mem_channel_buffer, q_device);

          kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
          // kernel_unloader_1
          log("kernel kernel_unloader_1");
          unloader_1_mem_channel = (float*)(((device_handle*) unloader_1_mem_channel_buffer->device)->mem);
          oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
            h.single_task<class kernel_unloader_1_class>([=](){
              Out_channel_array_t Out_channel_array;
              int addr_temp;
              addr_temp = 0;
              for (int b = 0; b < X_extent_1; b++) {
                Out_channel_array = Out_channel::read<>();
                auto _D4 = Out_channel_array.s;
                unloader_1_mem_channel[addr_temp] = _D4;
                addr_temp = addr_temp + 1;
              }
            }); //  h.single_task kernel_unloader_1_class
          })); // q_device.submit
          oneapi_kernel_events.back().wait();
          halide_sycl_device_and_host_free(xSerializer_1_mem_channel_buffer, q_device);

          halide_sycl_device_and_host_free(ySerializer_1_mem_channel_buffer, q_device);

          _halide_buffer_set_device_dirty(unloader_1_mem_channel_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
          {
            int32_t addr_temp;
            addr_temp = 0;
            int32_t halide_copy_to_host_result = 0;
            halide_sycl_buffer_copy(unloader_1_mem_channel_buffer, 1, q_device);
;
            int32_t halide_copy_to_host_result_3 = 0;
            halide_sycl_buffer_copy(deserializer_1_buffer, 1, q_device);
;
            // kernel_deserializer_1
            log("kernel kernel_deserializer_1");
            unloader_1_mem_channel = (float*)(unloader_1_mem_channel_buffer->host);
            float *deserializer_1 = (float*)(deserializer_1_buffer->host);
            {
              for (int b = 0; b < X_extent_1; b++) {
                auto _D5 = unloader_1_mem_channel[addr_temp];
                ((float *)deserializer_1)[b - deserializer_1_min_0] = _D5;
                addr_temp = addr_temp + 1;
              }
            }
            _halide_buffer_set_host_dirty(deserializer_1_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
            int32_t halide_device_and_host_free_result = 0;
            halide_sycl_device_and_host_free(unloader_1_mem_channel_buffer, q_device);
;
          }
          unloader_1_mem_channel = NULL;
        }
        ySerializer_1_mem_channel = NULL;
      }
      xSerializer_1_mem_channel = NULL;
    }
  }
#ifndef T2SP_NDEBUG
  uint64_t k_earliest_start_time = std::numeric_limits<
    typename sycl::info::event_profiling::command_start::return_type>::max();
  uint64_t k_latest_end_time = std::numeric_limits<
    typename sycl::info::event_profiling::command_end::return_type>::min();
  for (auto i : kernels_used_to_measure_time) {
    uint64_t tmp_start = oneapi_kernel_events[i].get_profiling_info<sycl::info::event_profiling::command_start>();
    uint64_t tmp_end = oneapi_kernel_events[i].get_profiling_info<sycl::info::event_profiling::command_end>();
    if (tmp_start < k_earliest_start_time) {
      k_earliest_start_time = tmp_start;
    }
    if (tmp_end > k_latest_end_time) {
      k_latest_end_time = tmp_end;
    }
  }
  std::cout << "// Execution time of the device kernels (in nanoseconds) = " << (kernels_used_to_measure_time.empty() ? 0 : k_latest_end_time - k_earliest_start_time) << "\n";
#endif
  return oneapi_kernel_events.back();
}
} // namespace t2sp::blas::row_major::sdotprod

