#if __has_include(<sycl/sycl.hpp>)
#include <sycl/sycl.hpp>
#else
#include <CL/sycl.hpp>
#endif
#include <sycl/ext/intel/fpga_extensions.hpp>

#include "halide_runtime_etc.hpp"
#include "pipe_wrapper.hpp"
#include "complex_helper.hpp"
#include "constexpr_math.hpp"
#include "tuple.hpp"
#include "unrolled_loop.hpp"

template <typename... Args>
void log(Args &&...args) {
#ifndef T2SP_NDEBUG
  ((std::cout << "[INFO] ") << ... << args) << "\n";
#endif
}

using namespace sycl;
namespace t2sp::blas::row_major::svecadd {

typedef union {
bool __attribute__ ((aligned(16))) s[16];
struct {bool s0,  s1,  s2,  s3,  s4,  s5,  s6,  s7,  s8,  s9,  sa,  sb,  sc,  sd,  se,  sf;};
} bool16;
using xLoader_channel = pipe_wrapper<class xLoader_channel_pipe, float16, 256>;
using yLoader_channel = pipe_wrapper<class yLoader_channel_pipe, float16, 256>;
using Z_channel = pipe_wrapper<class Z_channel_pipe, float16, 256>;
sycl::event svecadd(sycl::queue &q_device, float Alpha, struct halide_buffer_t *X_buffer, int32_t IncX, float Beta, struct halide_buffer_t *Y_buffer, int32_t IncY, struct halide_buffer_t *deserializer_buffer) {
  std::vector<sycl::event> oneapi_kernel_events{};
  std::vector<size_t> kernels_used_to_measure_time{};
  auto exception_handler = [](sycl::exception_list exceptions) {
    for (std::exception_ptr const &e : exceptions) {
      try {
        std::rethrow_exception(e);
      } catch (sycl::exception const &e) {
        std::cout << "Caught asynchronous SYCL exception:\n"
                  << e.what() << std::endl;
      }
    }
  };
  log("creating device queues");
  sycl::queue q_host(sycl::cpu_selector_v, exception_handler, sycl::property::queue::enable_profiling());
  log("Host: ", q_host.get_device().get_info<sycl::info::device::name>());
  log("Device: ", q_device.get_device().get_info<sycl::info::device::name>());
  sycl::device dev = q_device.get_device();
  void * const _ucon = nullptr;
  void * X = _halide_buffer_get_host(X_buffer);
  uint32_t X_type = _halide_buffer_get_type(X_buffer);
  int32_t X_dimensions = _halide_buffer_get_dimensions(X_buffer);
  int32_t X_min_0 = _halide_buffer_get_min(X_buffer, 0);
  int32_t X_extent_0 = _halide_buffer_get_extent(X_buffer, 0);
  int32_t X_stride_0 = _halide_buffer_get_stride(X_buffer, 0);
  int32_t X_min_1 = _halide_buffer_get_min(X_buffer, 1);
  int32_t X_extent_1 = _halide_buffer_get_extent(X_buffer, 1);
  int32_t X_stride_1 = _halide_buffer_get_stride(X_buffer, 1);
  void * Y = _halide_buffer_get_host(Y_buffer);
  uint32_t Y_type = _halide_buffer_get_type(Y_buffer);
  int32_t Y_dimensions = _halide_buffer_get_dimensions(Y_buffer);
  int32_t Y_min_0 = _halide_buffer_get_min(Y_buffer, 0);
  int32_t Y_extent_0 = _halide_buffer_get_extent(Y_buffer, 0);
  int32_t Y_stride_0 = _halide_buffer_get_stride(Y_buffer, 0);
  int32_t Y_min_1 = _halide_buffer_get_min(Y_buffer, 1);
  int32_t Y_extent_1 = _halide_buffer_get_extent(Y_buffer, 1);
  int32_t Y_stride_1 = _halide_buffer_get_stride(Y_buffer, 1);
  void * deserializer = _halide_buffer_get_host(deserializer_buffer);
  uint32_t deserializer_type = _halide_buffer_get_type(deserializer_buffer);
  int32_t deserializer_dimensions = _halide_buffer_get_dimensions(deserializer_buffer);
  int32_t deserializer_min_0 = _halide_buffer_get_min(deserializer_buffer, 0);
  int32_t deserializer_extent_0 = _halide_buffer_get_extent(deserializer_buffer, 0);
  int32_t deserializer_stride_0 = _halide_buffer_get_stride(deserializer_buffer, 0);
  int32_t deserializer_min_1 = _halide_buffer_get_min(deserializer_buffer, 1);
  int32_t deserializer_extent_1 = _halide_buffer_get_extent(deserializer_buffer, 1);
  int32_t deserializer_stride_1 = _halide_buffer_get_stride(deserializer_buffer, 1);
  int32_t deserializer_min_2 = _halide_buffer_get_min(deserializer_buffer, 2);
  int32_t deserializer_extent_2 = _halide_buffer_get_extent(deserializer_buffer, 2);
  int32_t deserializer_stride_2 = _halide_buffer_get_stride(deserializer_buffer, 2);
  int32_t deserializer_min_3 = _halide_buffer_get_min(deserializer_buffer, 3);
  int32_t deserializer_extent_3 = _halide_buffer_get_extent(deserializer_buffer, 3);
  int32_t deserializer_stride_3 = _halide_buffer_get_stride(deserializer_buffer, 3);
  if (_halide_buffer_is_bounds_query(X_buffer)) {
    struct halide_dimension_t s0[2] = {
      {X_min_0, X_extent_0, IncX, 0},
      {X_min_1, X_extent_1, X_extent_0, 0},
    };
  }
  if (_halide_buffer_is_bounds_query(Y_buffer)) {
    struct halide_dimension_t s1[2] = {
      {Y_min_0, Y_extent_0, IncY, 0},
      {Y_min_1, Y_extent_1, Y_extent_0, 0},
    };
  }
  if (_halide_buffer_is_bounds_query(deserializer_buffer)) {
    struct halide_dimension_t s2[4] = {
      {0, 16, 1, 0},
      {0, 32, 16, 0},
      {0, (X_extent_0 + 511) / 512, 512, 0},
      {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
    };
  }
  if (!(_halide_buffer_is_bounds_query(deserializer_buffer) || (_halide_buffer_is_bounds_query(X_buffer) || _halide_buffer_is_bounds_query(Y_buffer)))) {
    int64_t X_total_extent_1 = (int64_t)(X_extent_1) * (int64_t)(X_extent_0);
    int64_t Y_total_extent_1 = (int64_t)(Y_extent_1) * (int64_t)(Y_extent_0);
    int64_t deserializer_total_extent_1 = (int64_t)(deserializer_extent_1) * (int64_t)(deserializer_extent_0);
    int64_t deserializer_total_extent_2 = deserializer_total_extent_1 * (int64_t)(deserializer_extent_2);
    int64_t deserializer_total_extent_3 = deserializer_total_extent_2 * (int64_t)(deserializer_extent_3);
    halide_buffer_t b0;
    struct halide_dimension_t s3[4] = {
      {0, 16, 1, 0},
      {0, 32, 16, 0},
      {0, (X_extent_0 + 511) / 512, 512, 0},
      {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
    };
    struct halide_dimension_t s4[4] = {
      {0, 16, 1, 0},
      {0, 32, 16, 0},
      {0, (X_extent_0 + 511) / 512, 512, 0},
      {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
    };
    struct halide_buffer_t * serializer_mem_channel_buffer = _halide_buffer_init(&b0, s3, (void *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), (uint64_t)(ADD_UINT64_T_SUFFIX(0)), (struct halide_device_interface_t *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), 2, 32, 4, s4, (uint64_t)(ADD_UINT64_T_SUFFIX(0)));
    int32_t halide_device_and_host_malloc_result_2 = 0;
    halide_sycl_device_and_host_malloc(serializer_mem_channel_buffer, q_device);
;
    {
      float *serializer_mem_channel = (float *)(_halide_buffer_get_host(serializer_mem_channel_buffer));
      if (!serializer_mem_channel)
      {
        log("Condition 'serializer_mem_channel' failed with error id_msg: None");
        assert(false);
      }
      {
        int32_t addr_temp;
        addr_temp = 0;
        int32_t halide_copy_to_host_result_1 = 0;
        halide_sycl_buffer_copy(X_buffer, 1, q_device);
;
        // kernel_serializer
        log("kernel kernel_serializer");
        float *X = (float*)(X_buffer->host);
        serializer_mem_channel = (float*)(serializer_mem_channel_buffer->host);
        {
          for (int b = 0; b < X_extent_1; b++) {
            for (int k = 0; k < (X_extent_0 + 511) / 512; k++) {
              for (int kk = 0; kk < 32; kk++) {
                for (int kkk = 0; kkk < 16; kkk++) {
                  auto _D0 = (k * 512 + (kk * 16 + kkk)) * IncX + X_stride_1 * b - (IncX * X_min_0 + X_min_1 * X_stride_1);
                  auto _D1 = ((k * 32 + kk) * 16 < X_extent_0 ? ((float *)X)[_D0] : float_from_bits(0));
                  serializer_mem_channel[addr_temp] = _D1;
                  addr_temp = addr_temp + 1;
                }
              }
            }
          }
        }
        _halide_buffer_set_host_dirty(serializer_mem_channel_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
      }
      halide_sycl_buffer_copy(serializer_mem_channel_buffer, 0, q_device);

      kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
      // kernel_xLoader
      log("kernel kernel_xLoader");
      serializer_mem_channel = (float*)(((device_handle*) serializer_mem_channel_buffer->device)->mem);
      oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
        h.single_task<class kernel_xLoader_class>([=](){
          int addr_temp;
          addr_temp = 0;
          for (int b = 0; b < X_extent_1; b++) {
            for (int k = 0; k < (X_extent_0 + 511) >> 9; k++) {
              for (int kk = 0; kk < 32; kk++) {
                xLoader_channel::write<>(float16{
                  serializer_mem_channel[addr_temp * 16 + 0],
                  serializer_mem_channel[addr_temp * 16 + 1],
                  serializer_mem_channel[addr_temp * 16 + 2],
                  serializer_mem_channel[addr_temp * 16 + 3],
                  serializer_mem_channel[addr_temp * 16 + 4],
                  serializer_mem_channel[addr_temp * 16 + 5],
                  serializer_mem_channel[addr_temp * 16 + 6],
                  serializer_mem_channel[addr_temp * 16 + 7],
                  serializer_mem_channel[addr_temp * 16 + 8],
                  serializer_mem_channel[addr_temp * 16 + 9],
                  serializer_mem_channel[addr_temp * 16 + 10],
                  serializer_mem_channel[addr_temp * 16 + 11],
                  serializer_mem_channel[addr_temp * 16 + 12],
                  serializer_mem_channel[addr_temp * 16 + 13],
                  serializer_mem_channel[addr_temp * 16 + 14],
                  serializer_mem_channel[addr_temp * 16 + 15]
                });
                addr_temp = addr_temp + 1;
              }
            }
          }
        }); //  h.single_task kernel_xLoader_class
      })); // q_device.submit
      halide_buffer_t b1;
      struct halide_dimension_t s5[4] = {
        {0, 16, 1, 0},
        {0, 32, 16, 0},
        {0, (X_extent_0 + 511) / 512, 512, 0},
        {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
      };
      struct halide_dimension_t s6[4] = {
        {0, 16, 1, 0},
        {0, 32, 16, 0},
        {0, (X_extent_0 + 511) / 512, 512, 0},
        {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
      };
      struct halide_buffer_t * serializer_1_mem_channel_buffer = _halide_buffer_init(&b1, s5, (void *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), (uint64_t)(ADD_UINT64_T_SUFFIX(0)), (struct halide_device_interface_t *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), 2, 32, 4, s6, (uint64_t)(ADD_UINT64_T_SUFFIX(0)));
      int32_t halide_device_and_host_malloc_result_1 = 0;
      halide_sycl_device_and_host_malloc(serializer_1_mem_channel_buffer, q_device);
;
      {
        float *serializer_1_mem_channel = (float *)(_halide_buffer_get_host(serializer_1_mem_channel_buffer));
        if (!serializer_1_mem_channel)
        {
          log("Condition 'serializer_1_mem_channel' failed with error id_msg: None");
          assert(false);
        }
        {
          int32_t addr_temp;
          addr_temp = 0;
          int32_t halide_copy_to_host_result_2 = 0;
          halide_sycl_buffer_copy(Y_buffer, 1, q_device);
;
          // kernel_serializer_1
          log("kernel kernel_serializer_1");
          float *Y = (float*)(Y_buffer->host);
          serializer_1_mem_channel = (float*)(serializer_1_mem_channel_buffer->host);
          {
            for (int b = 0; b < X_extent_1; b++) {
              for (int k = 0; k < (X_extent_0 + 511) / 512; k++) {
                for (int kk = 0; kk < 32; kk++) {
                  for (int kkk = 0; kkk < 16; kkk++) {
                    auto _D2 = (k * 512 + (kk * 16 + kkk)) * IncY + Y_stride_1 * b - (IncY * Y_min_0 + Y_min_1 * Y_stride_1);
                    auto _D3 = ((k * 32 + kk) * 16 < X_extent_0 ? ((float *)Y)[_D2] : float_from_bits(0));
                    serializer_1_mem_channel[addr_temp] = _D3;
                    addr_temp = addr_temp + 1;
                  }
                }
              }
            }
          }
          _halide_buffer_set_host_dirty(serializer_1_mem_channel_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
        }
        halide_sycl_buffer_copy(serializer_1_mem_channel_buffer, 0, q_device);

        kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
        // kernel_yLoader
        log("kernel kernel_yLoader");
        serializer_1_mem_channel = (float*)(((device_handle*) serializer_1_mem_channel_buffer->device)->mem);
        oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
          h.single_task<class kernel_yLoader_class>([=](){
            int addr_temp;
            addr_temp = 0;
            for (int b = 0; b < X_extent_1; b++) {
              for (int k = 0; k < (X_extent_0 + 511) >> 9; k++) {
                for (int kk = 0; kk < 32; kk++) {
                  yLoader_channel::write<>(float16{
                    serializer_1_mem_channel[addr_temp * 16 + 0],
                    serializer_1_mem_channel[addr_temp * 16 + 1],
                    serializer_1_mem_channel[addr_temp * 16 + 2],
                    serializer_1_mem_channel[addr_temp * 16 + 3],
                    serializer_1_mem_channel[addr_temp * 16 + 4],
                    serializer_1_mem_channel[addr_temp * 16 + 5],
                    serializer_1_mem_channel[addr_temp * 16 + 6],
                    serializer_1_mem_channel[addr_temp * 16 + 7],
                    serializer_1_mem_channel[addr_temp * 16 + 8],
                    serializer_1_mem_channel[addr_temp * 16 + 9],
                    serializer_1_mem_channel[addr_temp * 16 + 10],
                    serializer_1_mem_channel[addr_temp * 16 + 11],
                    serializer_1_mem_channel[addr_temp * 16 + 12],
                    serializer_1_mem_channel[addr_temp * 16 + 13],
                    serializer_1_mem_channel[addr_temp * 16 + 14],
                    serializer_1_mem_channel[addr_temp * 16 + 15]
                  });
                  addr_temp = addr_temp + 1;
                }
              }
            }
          }); //  h.single_task kernel_yLoader_class
        })); // q_device.submit
        kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
        // kernel_Z
        log("kernel kernel_Z");
        oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
          h.single_task<class kernel_Z_class>([=](){
            for (int b = 0; b < X_extent_1; b++) {
              for (int k = 0; k < (X_extent_0 + 511) >> 9; k++) {
                for (int kk = 0; kk < 32; kk++) {
                  float16 uZ_1_shreg;
                  float16 uY_shreg;
                  float16 uX_shreg;
                  uX_shreg = xLoader_channel::read<>();
                  uY_shreg = yLoader_channel::read<>();
                  uZ_1_shreg = uX_shreg * Alpha + uY_shreg * Beta;
                  Z_channel::write<>(uZ_1_shreg);
                }
              }
            }
          }); //  h.single_task kernel_Z_class
        })); // q_device.submit
        halide_buffer_t b2;
        struct halide_dimension_t s7[4] = {
          {0, 16, 1, 0},
          {0, 32, 16, 0},
          {0, (X_extent_0 + 511) / 512, 512, 0},
          {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
        };
        struct halide_dimension_t s8[4] = {
          {0, 16, 1, 0},
          {0, 32, 16, 0},
          {0, (X_extent_0 + 511) / 512, 512, 0},
          {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
        };
        struct halide_buffer_t * unloader_mem_channel_buffer = _halide_buffer_init(&b2, s7, (void *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), (uint64_t)(ADD_UINT64_T_SUFFIX(0)), (struct halide_device_interface_t *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), 2, 32, 4, s8, (uint64_t)(ADD_UINT64_T_SUFFIX(0)));
        int32_t halide_device_and_host_malloc_result = 0;
        halide_sycl_device_and_host_malloc(unloader_mem_channel_buffer, q_device);
;
        {
          float *unloader_mem_channel = (float *)(_halide_buffer_get_host(unloader_mem_channel_buffer));
          if (!unloader_mem_channel)
          {
            log("Condition 'unloader_mem_channel' failed with error id_msg: None");
            assert(false);
          }
          halide_sycl_device_malloc(unloader_mem_channel_buffer, q_device);

          kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
          // kernel_unloader
          log("kernel kernel_unloader");
          unloader_mem_channel = (float*)(((device_handle*) unloader_mem_channel_buffer->device)->mem);
          oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
            h.single_task<class kernel_unloader_class>([=](){
              int addr_temp;
              addr_temp = 0;
              for (int b = 0; b < X_extent_1; b++) {
                for (int k = 0; k < (X_extent_0 + 511) >> 9; k++) {
                  for (int kk = 0; kk < 32; kk++) {
                    auto _D4 = Z_channel::read<>();
                    unloader_mem_channel[addr_temp * 16 + 0] = _D4[0];
                    unloader_mem_channel[addr_temp * 16 + 1] = _D4[1];
                    unloader_mem_channel[addr_temp * 16 + 2] = _D4[2];
                    unloader_mem_channel[addr_temp * 16 + 3] = _D4[3];
                    unloader_mem_channel[addr_temp * 16 + 4] = _D4[4];
                    unloader_mem_channel[addr_temp * 16 + 5] = _D4[5];
                    unloader_mem_channel[addr_temp * 16 + 6] = _D4[6];
                    unloader_mem_channel[addr_temp * 16 + 7] = _D4[7];
                    unloader_mem_channel[addr_temp * 16 + 8] = _D4[8];
                    unloader_mem_channel[addr_temp * 16 + 9] = _D4[9];
                    unloader_mem_channel[addr_temp * 16 + 10] = _D4[10];
                    unloader_mem_channel[addr_temp * 16 + 11] = _D4[11];
                    unloader_mem_channel[addr_temp * 16 + 12] = _D4[12];
                    unloader_mem_channel[addr_temp * 16 + 13] = _D4[13];
                    unloader_mem_channel[addr_temp * 16 + 14] = _D4[14];
                    unloader_mem_channel[addr_temp * 16 + 15] = _D4[15];
                    addr_temp = addr_temp + 1;
                  }
                }
              }
            }); //  h.single_task kernel_unloader_class
          })); // q_device.submit
          oneapi_kernel_events.back().wait();
          halide_sycl_device_and_host_free(serializer_mem_channel_buffer, q_device);

          halide_sycl_device_and_host_free(serializer_1_mem_channel_buffer, q_device);

          _halide_buffer_set_device_dirty(unloader_mem_channel_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
          {
            int32_t addr_temp;
            addr_temp = 0;
            int32_t halide_copy_to_host_result = 0;
            halide_sycl_buffer_copy(unloader_mem_channel_buffer, 1, q_device);
;
            int32_t halide_copy_to_host_result_3 = 0;
            halide_sycl_buffer_copy(deserializer_buffer, 1, q_device);
;
            // kernel_deserializer
            log("kernel kernel_deserializer");
            unloader_mem_channel = (float*)(unloader_mem_channel_buffer->host);
            float *deserializer = (float*)(deserializer_buffer->host);
            {
              for (int b = 0; b < X_extent_1; b++) {
                for (int k = 0; k < (X_extent_0 + 511) / 512; k++) {
                  for (int kk = 0; kk < 32; kk++) {
                    auto _D5 = float16{
                      unloader_mem_channel[addr_temp * 16 + 0],
                      unloader_mem_channel[addr_temp * 16 + 1],
                      unloader_mem_channel[addr_temp * 16 + 2],
                      unloader_mem_channel[addr_temp * 16 + 3],
                      unloader_mem_channel[addr_temp * 16 + 4],
                      unloader_mem_channel[addr_temp * 16 + 5],
                      unloader_mem_channel[addr_temp * 16 + 6],
                      unloader_mem_channel[addr_temp * 16 + 7],
                      unloader_mem_channel[addr_temp * 16 + 8],
                      unloader_mem_channel[addr_temp * 16 + 9],
                      unloader_mem_channel[addr_temp * 16 + 10],
                      unloader_mem_channel[addr_temp * 16 + 11],
                      unloader_mem_channel[addr_temp * 16 + 12],
                      unloader_mem_channel[addr_temp * 16 + 13],
                      unloader_mem_channel[addr_temp * 16 + 14],
                      unloader_mem_channel[addr_temp * 16 + 15]
                    };
                    auto _D6 = b * deserializer_stride_3 + (kk * deserializer_stride_1 + k * deserializer_stride_2) - (deserializer_min_3 * deserializer_stride_3 + (deserializer_min_2 * deserializer_stride_2 + (deserializer_min_1 * deserializer_stride_1 + deserializer_min_0)));
                    deserializer[_D6 + 0] = _D5[0];
                    deserializer[_D6 + 1] = _D5[1];
                    deserializer[_D6 + 2] = _D5[2];
                    deserializer[_D6 + 3] = _D5[3];
                    deserializer[_D6 + 4] = _D5[4];
                    deserializer[_D6 + 5] = _D5[5];
                    deserializer[_D6 + 6] = _D5[6];
                    deserializer[_D6 + 7] = _D5[7];
                    deserializer[_D6 + 8] = _D5[8];
                    deserializer[_D6 + 9] = _D5[9];
                    deserializer[_D6 + 10] = _D5[10];
                    deserializer[_D6 + 11] = _D5[11];
                    deserializer[_D6 + 12] = _D5[12];
                    deserializer[_D6 + 13] = _D5[13];
                    deserializer[_D6 + 14] = _D5[14];
                    deserializer[_D6 + 15] = _D5[15];
                    addr_temp = addr_temp + 1;
                  }
                }
              }
            }
            _halide_buffer_set_host_dirty(deserializer_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
            int32_t halide_device_and_host_free_result = 0;
            halide_sycl_device_and_host_free(unloader_mem_channel_buffer, q_device);
;
          }
          unloader_mem_channel = NULL;
        }
        serializer_1_mem_channel = NULL;
      }
      serializer_mem_channel = NULL;
    }
  }
#ifndef T2SP_NDEBUG
  uint64_t k_earliest_start_time = std::numeric_limits<
    typename sycl::info::event_profiling::command_start::return_type>::max();
  uint64_t k_latest_end_time = std::numeric_limits<
    typename sycl::info::event_profiling::command_end::return_type>::min();
  for (auto i : kernels_used_to_measure_time) {
    uint64_t tmp_start = oneapi_kernel_events[i].get_profiling_info<sycl::info::event_profiling::command_start>();
    uint64_t tmp_end = oneapi_kernel_events[i].get_profiling_info<sycl::info::event_profiling::command_end>();
    if (tmp_start < k_earliest_start_time) {
      k_earliest_start_time = tmp_start;
    }
    if (tmp_end > k_latest_end_time) {
      k_latest_end_time = tmp_end;
    }
  }
  std::cout << "// Execution time of the device kernels (in nanoseconds) = " << (kernels_used_to_measure_time.empty() ? 0 : k_latest_end_time - k_earliest_start_time) << "\n";
#endif
  return oneapi_kernel_events.back();
}
} // namespace t2sp::blas::row_major::svecadd

