#if __has_include(<sycl/sycl.hpp>)
#include <sycl/sycl.hpp>
#else
#include <CL/sycl.hpp>
#endif
#include <sycl/ext/intel/fpga_extensions.hpp>

#include "halide_runtime_etc.hpp"
#include "pipe_wrapper.hpp"
#include "complex_helper.hpp"
#include "constexpr_math.hpp"
#include "tuple.hpp"
#include "unrolled_loop.hpp"

template <typename... Args>
void log(Args &&...args) {
#ifndef T2SP_NDEBUG
  ((std::cout << "[INFO] ") << ... << args) << "\n";
#endif
}

using namespace sycl;
namespace t2sp::blas::row_major::ddotprod {

typedef union bool8_t {
    bool __attribute__ ((aligned(8))) s[8] {};
    struct {bool s0,  s1,  s2,  s3,  s4,  s5,  s6,  s7;};
    bool &operator[](int i) { return s[i]; }
} bool8;
using xLoader_channel = pipe_wrapper<class xLoader_channel_pipe, double8, 256>;
using yLoader_channel = pipe_wrapper<class yLoader_channel_pipe, double8, 256>;
using Z_channel = pipe_wrapper<class Z_channel_pipe, double, 0>;
struct Out_channel_array_t { double s; };
using Out_channel = pipe_wrapper<class Out_channel_pipe, Out_channel_array_t, 256>;
sycl::event ddotprod(sycl::queue &q_device, bool ConjugateX, struct halide_buffer_t *X_buffer, int32_t IncX, bool SignBitY, struct halide_buffer_t *Y_buffer, int32_t IncY, bool SqrtRet, struct halide_buffer_t *deserializer_buffer) {
  std::vector<sycl::event> oneapi_kernel_events{};
  std::vector<size_t> kernels_used_to_measure_time{};
  auto exception_handler = [](sycl::exception_list exceptions) {
    for (std::exception_ptr const &e : exceptions) {
      try {
        std::rethrow_exception(e);
      } catch (sycl::exception const &e) {
        std::cout << "Caught asynchronous SYCL exception:\n"
                  << e.what() << std::endl;
      }
    }
  };
  log("creating device queues");
  sycl::queue q_host(sycl::cpu_selector_v, exception_handler, sycl::property::queue::enable_profiling());
  log("Host: ", q_host.get_device().get_info<sycl::info::device::name>());
  log("Device: ", q_device.get_device().get_info<sycl::info::device::name>());
  sycl::device dev = q_device.get_device();
  void * const _ucon = nullptr;
  void * X = _halide_buffer_get_host(X_buffer);
  uint32_t X_type = _halide_buffer_get_type(X_buffer);
  int32_t X_dimensions = _halide_buffer_get_dimensions(X_buffer);
  int32_t X_min_0 = _halide_buffer_get_min(X_buffer, 0);
  int32_t X_extent_0 = _halide_buffer_get_extent(X_buffer, 0);
  int32_t X_stride_0 = _halide_buffer_get_stride(X_buffer, 0);
  int32_t X_min_1 = _halide_buffer_get_min(X_buffer, 1);
  int32_t X_extent_1 = _halide_buffer_get_extent(X_buffer, 1);
  int32_t X_stride_1 = _halide_buffer_get_stride(X_buffer, 1);
  void * Y = _halide_buffer_get_host(Y_buffer);
  uint32_t Y_type = _halide_buffer_get_type(Y_buffer);
  int32_t Y_dimensions = _halide_buffer_get_dimensions(Y_buffer);
  int32_t Y_min_0 = _halide_buffer_get_min(Y_buffer, 0);
  int32_t Y_extent_0 = _halide_buffer_get_extent(Y_buffer, 0);
  int32_t Y_stride_0 = _halide_buffer_get_stride(Y_buffer, 0);
  int32_t Y_min_1 = _halide_buffer_get_min(Y_buffer, 1);
  int32_t Y_extent_1 = _halide_buffer_get_extent(Y_buffer, 1);
  int32_t Y_stride_1 = _halide_buffer_get_stride(Y_buffer, 1);
  void * deserializer = _halide_buffer_get_host(deserializer_buffer);
  uint32_t deserializer_type = _halide_buffer_get_type(deserializer_buffer);
  int32_t deserializer_dimensions = _halide_buffer_get_dimensions(deserializer_buffer);
  int32_t deserializer_min_0 = _halide_buffer_get_min(deserializer_buffer, 0);
  int32_t deserializer_extent_0 = _halide_buffer_get_extent(deserializer_buffer, 0);
  int32_t deserializer_stride_0 = _halide_buffer_get_stride(deserializer_buffer, 0);
  if (_halide_buffer_is_bounds_query(X_buffer)) {
    struct halide_dimension_t s0[2] = {
      {X_min_0, X_extent_0, IncX, 0},
      {X_min_1, X_extent_1, X_extent_0, 0},
    };
  }
  if (_halide_buffer_is_bounds_query(Y_buffer)) {
    struct halide_dimension_t s1[2] = {
      {Y_min_0, Y_extent_0, IncY, 0},
      {Y_min_1, Y_extent_1, Y_extent_0, 0},
    };
  }
  if (_halide_buffer_is_bounds_query(deserializer_buffer)) {
    struct halide_dimension_t s2[1] = {
      {0, X_extent_1, 1, 0},
    };
  }
  if (!(_halide_buffer_is_bounds_query(deserializer_buffer) || (_halide_buffer_is_bounds_query(X_buffer) || _halide_buffer_is_bounds_query(Y_buffer)))) {
    int64_t X_total_extent_1 = (int64_t)(X_extent_1) * (int64_t)(X_extent_0);
    int64_t Y_total_extent_1 = (int64_t)(Y_extent_1) * (int64_t)(Y_extent_0);
    halide_buffer_t b0;
    struct halide_dimension_t s3[4] = {
      {0, 8, 1, 0},
      {0, 64, 8, 0},
      {0, (X_extent_0 + 511) / 512, 512, 0},
      {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
    };
    struct halide_dimension_t s4[4] = {
      {0, 8, 1, 0},
      {0, 64, 8, 0},
      {0, (X_extent_0 + 511) / 512, 512, 0},
      {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
    };
    struct halide_buffer_t * serializer_mem_channel_buffer = _halide_buffer_init(&b0, s3, (void *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), (uint64_t)(ADD_UINT64_T_SUFFIX(0)), (struct halide_device_interface_t *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), 2, 64, 4, s4, (uint64_t)(ADD_UINT64_T_SUFFIX(0)));
    int32_t halide_device_and_host_malloc_result_2 = 0;
    halide_sycl_device_and_host_malloc(serializer_mem_channel_buffer, q_device);
;
    {
      double *serializer_mem_channel = (double *)(_halide_buffer_get_host(serializer_mem_channel_buffer));
      if (!serializer_mem_channel)
      {
        log("Condition 'serializer_mem_channel' failed with error id_msg: None");
        assert(false);
      }
      {
        int32_t addr_temp;
        addr_temp = 0;
        int32_t halide_copy_to_host_result_1 = 0;
        halide_sycl_buffer_copy(X_buffer, 1, q_device);
;
        // kernel_serializer
        log("kernel kernel_serializer");
        double *X = (double*)(X_buffer->host);
        serializer_mem_channel = (double*)(serializer_mem_channel_buffer->host);
        {
          for (int b = 0; b < X_extent_1; b++) {
            for (int k = 0; k < (X_extent_0 + 511) / 512; k++) {
              for (int kk = 0; kk < 64; kk++) {
                for (int kkk = 0; kkk < 8; kkk++) {
                  auto _D0 = (k * 512 + (kk * 8 + kkk)) * IncX + X_stride_1 * b - (IncX * X_min_0 + X_min_1 * X_stride_1);
                  auto _D1 = ((k * 64 + kk) * 8 < X_extent_0 ? ((double *)X)[_D0] : (double) float_from_bits(0));
                  serializer_mem_channel[addr_temp] = _D1;
                  addr_temp = addr_temp + 1;
                }
              }
            }
          }
        }
        _halide_buffer_set_host_dirty(serializer_mem_channel_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
      }
      halide_sycl_buffer_copy(serializer_mem_channel_buffer, 0, q_device);

      kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
      // kernel_xLoader
      log("kernel kernel_xLoader");
      serializer_mem_channel = (double*)(((device_handle*) serializer_mem_channel_buffer->device)->mem);
      oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
        h.single_task<class kernel_xLoader_class>([=](){
          int addr_temp;
          addr_temp = 0;
          for (int b = 0; b < X_extent_1; b++) {
            for (int k = 0; k < (X_extent_0 + 511) >> 9; k++) {
              for (int kk = 0; kk < 64; kk++) {
                xLoader_channel::write<>(double8{
                  serializer_mem_channel[addr_temp * 8 + 0],
                  serializer_mem_channel[addr_temp * 8 + 1],
                  serializer_mem_channel[addr_temp * 8 + 2],
                  serializer_mem_channel[addr_temp * 8 + 3],
                  serializer_mem_channel[addr_temp * 8 + 4],
                  serializer_mem_channel[addr_temp * 8 + 5],
                  serializer_mem_channel[addr_temp * 8 + 6],
                  serializer_mem_channel[addr_temp * 8 + 7]
                });
                addr_temp = addr_temp + 1;
              }
            }
          }
        }); //  h.single_task kernel_xLoader_class
      })); // q_device.submit
      halide_buffer_t b1;
      struct halide_dimension_t s5[4] = {
        {0, 8, 1, 0},
        {0, 64, 8, 0},
        {0, (X_extent_0 + 511) / 512, 512, 0},
        {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
      };
      struct halide_dimension_t s6[4] = {
        {0, 8, 1, 0},
        {0, 64, 8, 0},
        {0, (X_extent_0 + 511) / 512, 512, 0},
        {0, X_extent_1, (X_extent_0 + 511) / 512 * 512, 0},
      };
      struct halide_buffer_t * serializer_1_mem_channel_buffer = _halide_buffer_init(&b1, s5, (void *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), (uint64_t)(ADD_UINT64_T_SUFFIX(0)), (struct halide_device_interface_t *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), 2, 64, 4, s6, (uint64_t)(ADD_UINT64_T_SUFFIX(0)));
      int32_t halide_device_and_host_malloc_result_1 = 0;
      halide_sycl_device_and_host_malloc(serializer_1_mem_channel_buffer, q_device);
;
      {
        double *serializer_1_mem_channel = (double *)(_halide_buffer_get_host(serializer_1_mem_channel_buffer));
        if (!serializer_1_mem_channel)
        {
          log("Condition 'serializer_1_mem_channel' failed with error id_msg: None");
          assert(false);
        }
        {
          int32_t addr_temp;
          addr_temp = 0;
          int32_t halide_copy_to_host_result_2 = 0;
          halide_sycl_buffer_copy(Y_buffer, 1, q_device);
;
          // kernel_serializer_1
          log("kernel kernel_serializer_1");
          double *Y = (double*)(Y_buffer->host);
          serializer_1_mem_channel = (double*)(serializer_1_mem_channel_buffer->host);
          {
            for (int b = 0; b < X_extent_1; b++) {
              for (int k = 0; k < (X_extent_0 + 511) / 512; k++) {
                for (int kk = 0; kk < 64; kk++) {
                  for (int kkk = 0; kkk < 8; kkk++) {
                    auto _D2 = (k * 512 + (kk * 8 + kkk)) * IncY + Y_stride_1 * b - (IncY * Y_min_0 + Y_min_1 * Y_stride_1);
                    auto _D3 = (k * 512 + (kk * 8 + kkk)) * IncY + Y_stride_1 * b - (IncY * Y_min_0 + Y_min_1 * Y_stride_1);
                    auto _D4 = ((k * 64 + kk) * 8 < X_extent_0 ? halide_conditional_signbit(SignBitY, ((double *)Y)[_D3]) /* conditional_signbit_f64(SignBitY, ((double *)Y)[_D2]) replaced */ : (double) float_from_bits(0));
                    serializer_1_mem_channel[addr_temp] = _D4;
                    addr_temp = addr_temp + 1;
                  }
                }
              }
            }
          }
          _halide_buffer_set_host_dirty(serializer_1_mem_channel_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
        }
        halide_sycl_buffer_copy(serializer_1_mem_channel_buffer, 0, q_device);

        kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
        // kernel_yLoader
        log("kernel kernel_yLoader");
        serializer_1_mem_channel = (double*)(((device_handle*) serializer_1_mem_channel_buffer->device)->mem);
        oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
          h.single_task<class kernel_yLoader_class>([=](){
            int addr_temp;
            addr_temp = 0;
            for (int b = 0; b < X_extent_1; b++) {
              for (int k = 0; k < (X_extent_0 + 511) >> 9; k++) {
                for (int kk = 0; kk < 64; kk++) {
                  yLoader_channel::write<>(double8{
                    serializer_1_mem_channel[addr_temp * 8 + 0],
                    serializer_1_mem_channel[addr_temp * 8 + 1],
                    serializer_1_mem_channel[addr_temp * 8 + 2],
                    serializer_1_mem_channel[addr_temp * 8 + 3],
                    serializer_1_mem_channel[addr_temp * 8 + 4],
                    serializer_1_mem_channel[addr_temp * 8 + 5],
                    serializer_1_mem_channel[addr_temp * 8 + 6],
                    serializer_1_mem_channel[addr_temp * 8 + 7]
                  });
                  addr_temp = addr_temp + 1;
                }
              }
            }
          }); //  h.single_task kernel_yLoader_class
        })); // q_device.submit
        kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
        // kernel_Out
        log("kernel kernel_Out");
        oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
          h.single_task<class kernel_Out_class>([=](){
            Out_channel_array_t Out_channel_array;
            for (int b = 0; b < X_extent_1; b++) {
              int addr_temp;
              addr_temp = 0;
              double uZ_1_shreg[64];
              double Z_temp_shreg[64];
              for (int k = 0; k < (X_extent_0 + 511) >> 9; k++) {
                for (int kk = 0; kk < 64; kk++) {
                  double uZ_1;
                  uZ_1 = uZ_1_shreg[63];
                  fpga_tools::UnrolledLoop<63>([&](auto l1) {
                    uZ_1_shreg[63 - l1] = uZ_1_shreg[62 - l1];
                  });
                  uZ_1_shreg[0] = uZ_1;
                  double8 uY_shreg;
                  double8 uX_shreg;
                  uX_shreg = xLoader_channel::read<>();
                  uY_shreg = yLoader_channel::read<>();
                  double uZ_1_shreg_;
                  uZ_1_shreg_ = (k == 0 ? (double) float_from_bits(0) : sycl::ext::intel::fpga_reg(uZ_1_shreg[0]));
                  fpga_tools::UnrolledLoop<8>([&](auto kkk) {
                    uZ_1_shreg_ = uZ_1_shreg_ + uX_shreg[kkk] * uY_shreg[kkk];
                    if ((kkk & 3) == 3) {
                      uZ_1_shreg_ = sycl::ext::intel::fpga_reg(uZ_1_shreg_);
                    }
                  });
                  uZ_1_shreg[0] = uZ_1_shreg_;
                  fpga_tools::UnrolledLoop<8>([&](auto kkk) {
                    if (k == (X_extent_0 - 1) >> 9 && kkk == 7) {
                      Z_temp_shreg[addr_temp] = uZ_1_shreg[0];
                      addr_temp = addr_temp + 1;
                    }
                  });
                }
              }
              addr_temp = 0;
              double uZ_2_shreg;
              for (int kk = 0; kk < 64; kk++) {
                uZ_2_shreg = Z_temp_shreg[addr_temp] + ((kk == 0 ? (double) float_from_bits(0) : uZ_2_shreg));
                if (kk == 63) {
                  Out_channel_array.s = (SqrtRet ? std::sqrt(uZ_2_shreg) : uZ_2_shreg) /* conditional_sqrt_f64(SqrtRet, uZ_2_shreg) replaced */;
                }
                addr_temp = addr_temp + 1;
              }
              Out_channel::write<>(Out_channel_array);
            }
          }); //  h.single_task kernel_Out_class
        })); // q_device.submit
        halide_buffer_t b2;
        struct halide_dimension_t s7[1] = {
          {0, X_extent_1, 1, 0},
        };
        struct halide_dimension_t s8[1] = {
          {0, X_extent_1, 1, 0},
        };
        struct halide_buffer_t * unloader_mem_channel_buffer = _halide_buffer_init(&b2, s7, (void *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), (uint64_t)(ADD_UINT64_T_SUFFIX(0)), (struct halide_device_interface_t *)((uint64_t)(ADD_UINT64_T_SUFFIX(0))), 2, 64, 1, s8, (uint64_t)(ADD_UINT64_T_SUFFIX(0)));
        int32_t halide_device_and_host_malloc_result = 0;
        halide_sycl_device_and_host_malloc(unloader_mem_channel_buffer, q_device);
;
        {
          double *unloader_mem_channel = (double *)(_halide_buffer_get_host(unloader_mem_channel_buffer));
          if (!unloader_mem_channel)
          {
            log("Condition 'unloader_mem_channel' failed with error id_msg: None");
            assert(false);
          }
          halide_sycl_device_malloc(unloader_mem_channel_buffer, q_device);

          kernels_used_to_measure_time.push_back(oneapi_kernel_events.size());
          // kernel_unloader
          log("kernel kernel_unloader");
          unloader_mem_channel = (double*)(((device_handle*) unloader_mem_channel_buffer->device)->mem);
          oneapi_kernel_events.push_back(q_device.submit([&](sycl::handler &h){
            h.single_task<class kernel_unloader_class>([=](){
              Out_channel_array_t Out_channel_array;
              int addr_temp;
              addr_temp = 0;
              for (int b = 0; b < X_extent_1; b++) {
                Out_channel_array = Out_channel::read<>();
                auto _D5 = Out_channel_array.s;
                unloader_mem_channel[addr_temp] = _D5;
                addr_temp = addr_temp + 1;
              }
            }); //  h.single_task kernel_unloader_class
          })); // q_device.submit
          oneapi_kernel_events.back().wait();
          halide_sycl_device_and_host_free(serializer_mem_channel_buffer, q_device);

          halide_sycl_device_and_host_free(serializer_1_mem_channel_buffer, q_device);

          _halide_buffer_set_device_dirty(unloader_mem_channel_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
          {
            int32_t addr_temp;
            addr_temp = 0;
            int32_t halide_copy_to_host_result = 0;
            halide_sycl_buffer_copy(unloader_mem_channel_buffer, 1, q_device);
;
            int32_t halide_copy_to_host_result_3 = 0;
            halide_sycl_buffer_copy(deserializer_buffer, 1, q_device);
;
            // kernel_deserializer
            log("kernel kernel_deserializer");
            unloader_mem_channel = (double*)(unloader_mem_channel_buffer->host);
            double *deserializer = (double*)(deserializer_buffer->host);
            {
              for (int b = 0; b < X_extent_1; b++) {
                ((double *)deserializer)[b - deserializer_min_0] = unloader_mem_channel[addr_temp];
                addr_temp = addr_temp + 1;
              }
            }
            _halide_buffer_set_host_dirty(deserializer_buffer, (bool)(ADD_UINT64_T_SUFFIX(1)));
            int32_t halide_device_and_host_free_result = 0;
            halide_sycl_device_and_host_free(unloader_mem_channel_buffer, q_device);
;
          }
          unloader_mem_channel = NULL;
        }
        serializer_1_mem_channel = NULL;
      }
      serializer_mem_channel = NULL;
    }
  }
  return oneapi_kernel_events.back();
}
} // namespace t2sp::blas::row_major::ddotprod

